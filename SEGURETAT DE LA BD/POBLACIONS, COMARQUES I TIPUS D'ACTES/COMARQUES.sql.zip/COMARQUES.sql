-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-04-2010 a las 19:13:58
-- Versión del servidor: 5.1.30
-- Versión de PHP: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `agenda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comarques`
--

CREATE TABLE IF NOT EXISTS `comarques` (
  `id_comarca` int(2) NOT NULL,
  `nom_comarca` varchar(200) NOT NULL,
  PRIMARY KEY (`id_comarca`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `comarques`
--

INSERT INTO `comarques` (`id_comarca`, `nom_comarca`) VALUES
(36, 'Tarragonès'),
(35, 'Solsonès'),
(34, 'Selva'),
(33, 'Segrià'),
(32, 'Segarra'),
(31, 'Ripollès'),
(30, 'Ribera d''Ebre'),
(29, 'Priorat'),
(28, 'Pla de l''Estany'),
(27, 'Pla d''Urgell'),
(26, 'Pallars Sobirà'),
(25, 'Pallars Jussà'),
(24, 'Osona'),
(23, 'Noguera'),
(22, 'Montsià'),
(21, 'Maresme'),
(20, 'Gironès'),
(19, 'Garrotxa'),
(18, 'Garrigues'),
(17, 'Garraf'),
(16, 'Conca de Barberà'),
(15, 'Cerdanya'),
(14, 'Berguedà'),
(13, 'Barcelonès'),
(12, 'Baix Penedès'),
(11, 'Baix Llobregat'),
(10, 'Baix Empordà'),
(9, 'Baix Ebre'),
(8, 'Baix Camp'),
(7, 'Bages'),
(6, 'Anoia'),
(5, 'Alta Ribagorça'),
(4, 'Alt Urgell'),
(3, 'Alt Penedès'),
(2, 'Alt Empordà'),
(1, 'Alt Camp'),
(37, 'Terra Alta'),
(38, 'Urgell'),
(39, 'Val d''Aran'),
(40, 'Vallès Occidental'),
(41, 'Vallès Oriental');
