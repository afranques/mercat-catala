-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-04-2010 a las 19:14:35
-- Versión del servidor: 5.1.30
-- Versión de PHP: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `agenda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipus_actes`
--

CREATE TABLE IF NOT EXISTS `tipus_actes` (
  `id_acte` int(2) NOT NULL,
  `tipus_acte` text NOT NULL,
  PRIMARY KEY (`id_acte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `tipus_actes`
--

INSERT INTO `tipus_actes` (`id_acte`, `tipus_acte`) VALUES
(0, 'Altres'),
(1, 'Altres accions escèniques'),
(2, 'Aplecs i ballades'),
(3, 'Cicles musicals'),
(4, 'Concerts'),
(5, 'Conferències, xerrades i tertúlies'),
(6, 'Cursos, tallers i seminaris'),
(7, 'Espectacles'),
(8, 'Exhibició castellera'),
(9, 'Exposicions i instal·lacions'),
(10, 'Festes'),
(11, 'Festivals i mostres d’arts escèniques i de carrer'),
(12, 'Festivals i mostres de cinema i vídeo'),
(13, 'Festivals musicals'),
(14, 'Festivals pluridisciplinaris'),
(15, 'Fires i salons'),
(16, 'Jornades i congressos'),
(17, 'Narracions, lectures i recitals'),
(18, 'Parcs infantils i juvenils'),
(19, 'Performances'),
(20, 'Portes obertes'),
(21, 'Presentacions'),
(22, 'Projeccions'),
(23, 'Rutes i itineraris'),
(24, 'Taules rodones i debats'),
(25, 'Trobades'),
(26, 'Visites');
